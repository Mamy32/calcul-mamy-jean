<template>
  <Calculator msg="My calculator"/>
</template>

<script>
import Calculator from './components/Calculator.vue'

export default{
  name: 'App',
  components: {
    Calculator
  }
}
</script>
<style lang="scss">
@import './public/scss/style.scss';
</style>

