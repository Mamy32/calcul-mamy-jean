<template>
  <div class="calculator">
    <div class="display">{{ current || '0' }}</div>
    <div @click="clear" class="btn">C</div>
    <div @click="append('%')" class="btn">%</div>
    <div @click="backspc" class="btn">⌫</div>
    <div @click="append('÷')" class="btn operator">÷</div>
    <div @click="append('7')" class="btn">7</div>
    <div @click="append('8')" class="btn">8</div>
    <div @click="append('9')" class="btn">9</div>
    <div @click="append('x')" class="btn operator">x</div>
    <div @click="append('4')" class="btn">4</div>
    <div @click="append('5')" class="btn">5</div>
    <div @click="append('6')" class="btn">6</div>
    <div @click="append('-')" class="btn operator">-</div>
    <div @click="append('1')" class="btn">1</div>
    <div @click="append('2')" class="btn">2</div>
    <div @click="append('3')" class="btn">3</div>
    <div @click="append('+')" class="btn operator">+</div>
    <div @click="append('0')" class="btn zero">0</div>
    <div @click="dot" class="btn">.</div>
    <div @click="pow" class="btn operator">x²</div>
    <div @click="fact" class="btn operator">n!</div>
    <div @click="append('(')" class="btn operator">(</div>
    <div @click="append(')')" class="btn operator">)</div>
    <div @click="sqrt" class="btn operator">√</div>
    <div @click="equal" class="btn operator bg-danger">=</div>
  </div>
</template>

<script>
import * as math from 'mathjs';

export default {
  data() {
    return {
      current: '',
      openParenthesis: 0,
      closedParenthesis: 0
    }
  },
  methods: {
    clear() {
      this.current = '';
      this.openParenthesis = 0;
      this.closedParenthesis = 0;
    },
    append(char) {
      this.current += char;
      if (char === '(') {
        this.openParenthesis++;
      } else if (char === ')') {
        this.closedParenthesis++;
      }
    },
    dot() {
      if (!this.current.endsWith('.')) {
        this.append('.');
      }
    },
    equal() {
      if (this.openParenthesis !== this.closedParenthesis) {
        this.current = 'Error: Unbalanced Parentheses';
        return;
      }
      try {
        let expression = this.current.replace(/÷/g, '/').replace(/x/g, '*').replace(/%/g, ' % ');
        expression = expression.replace(/√\(([^)]+)\)/g, 'sqrt($1)');
        expression = expression.replace(/(\d+)x²/g, '($1^2)');
        expression = expression.replace(/(\d+)!/g, (match, n) => {
          return math.factorial(parseInt(n));
        });
        this.current = `${math.evaluate(expression)}`;
      } catch (e) {
        this.current = 'Error';
      }
      this.openParenthesis = 0;
      this.closedParenthesis = 0;
    },
    pow() {
      this.append('^2');
    },
    sqrt() {
      this.append('√(');
      this.openParenthesis++;
    },
    fact() {
      if (this.current !== '' && !isNaN(this.current.slice(-1))) {
        this.append('!');
      }
    },
    backspc() {
      if (this.current.endsWith(')')) {
        this.closedParenthesis--;
      } else if (this.current.endsWith('(')) {
        this.openParenthesis--;
      }
      this.current = this.current.slice(0, -1);
    }
  }
}
</script>

